#!/usr/bin/env python3
# Created by Gabriel A
# Created on Nov 2019
# This module contains constants (2π)

tpi = 6.28318530718
